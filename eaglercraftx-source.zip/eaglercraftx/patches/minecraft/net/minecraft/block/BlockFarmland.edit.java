
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 7

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> DELETE  7  @  7 : 8

> CHANGE  32 : 33  @  32 : 33

~ 	public void updateTick(World world, BlockPos blockpos, IBlockState iblockstate, EaglercraftRandom var4) {

> DELETE  15  @  15 : 23

> CHANGE  43 : 44  @  43 : 44

~ 	public Item getItemDropped(IBlockState var1, EaglercraftRandom random, int i) {

> EOF
