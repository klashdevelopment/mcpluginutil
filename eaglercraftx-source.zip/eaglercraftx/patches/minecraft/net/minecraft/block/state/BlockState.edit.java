
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  2 : 12  @  2

+ import java.util.ArrayList;
+ import java.util.Arrays;
+ import java.util.Collection;
+ import java.util.Collections;
+ import java.util.Comparator;
+ import java.util.HashMap;
+ import java.util.LinkedHashMap;
+ import java.util.List;
+ import java.util.Map;
+ 

> CHANGE  10 : 11  @  10 : 19

~ 

> DELETE  2  @  2 : 4

> CHANGE  23 : 24  @  23 : 24

~ 		ArrayList<BlockState.StateImplementation> arraylist = Lists.newArrayList();

> CHANGE  107 : 108  @  107 : 108

~ 					for (Object comparable : iproperty.getAllowedValues()) {

> CHANGE  2 : 3  @  2 : 3

~ 									map.get(this.getPropertiesWithValue(iproperty, (Comparable) comparable)));

> EOF
