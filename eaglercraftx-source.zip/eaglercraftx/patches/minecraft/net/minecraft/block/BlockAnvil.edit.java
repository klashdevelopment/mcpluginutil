
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ 

> DELETE  51  @  51 : 60

> INSERT  41 : 46  @  41

+ 	public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn,
+ 			EnumFacing side, float hitX, float hitY, float hitZ) {
+ 		return true;
+ 	}
+ 

> EOF
