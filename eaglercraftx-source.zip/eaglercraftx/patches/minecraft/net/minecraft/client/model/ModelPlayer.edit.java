
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 5

~ import net.lax1dude.eaglercraft.v1_8.opengl.GlStateManager;

> CHANGE  72 : 73  @  72 : 73

~ 			if (entity != null && entity.isSneaking()) {

> CHANGE  31 : 32  @  31 : 32

~ 		if (entity != null && entity.isSneaking()) {

> EOF
