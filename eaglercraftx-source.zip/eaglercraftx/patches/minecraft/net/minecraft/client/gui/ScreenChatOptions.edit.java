
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 7

> CHANGE  39 : 40  @  39 : 40

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> EOF
