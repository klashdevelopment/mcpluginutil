
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 4

> INSERT  2 : 6  @  2

+ 
+ import com.google.common.collect.Lists;
+ import com.google.common.collect.Maps;
+ 

> DELETE  1  @  1 : 6

> CHANGE  34 : 35  @  34 : 35

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> INSERT  56 : 58  @  56

+ 			this.mc.loadingScreen.eaglerShow(I18n.format("resourcePack.load.refreshing"),
+ 					I18n.format("resourcePack.load.pleaseWait"));

> INSERT  9 : 10  @  9

+ 			GuiLanguage.this.mc.displayGuiScreen(GuiLanguage.this);

> EOF
