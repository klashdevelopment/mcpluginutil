
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.mojang.authlib.GameProfile;
~ import net.lax1dude.eaglercraft.v1_8.opengl.GlStateManager;

> DELETE  3  @  3 : 6

> DELETE  7  @  7 : 8

> DELETE  3  @  3 : 5

> CHANGE  11 : 13  @  11 : 12

~ 		Minecraft.getMinecraft().getTextureManager().bindTexture(
~ 				Minecraft.getMinecraft().getNetHandler().getSkinCache().getSkin(profile).getResourceLocation());

> EOF
