
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 7

> CHANGE  11 : 12  @  11 : 12

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> CHANGE  8 : 9  @  8 : 9

~ 	protected void keyTyped(char parChar1, int parInt1) {

> EOF
